
BernieSanderDataset - v5 fit_edges_20x_aug_jn
==============================

This dataset was exported via roboflow.ai on February 3, 2021 at 6:16 PM GMT

It includes 3824 images.
Bernie are annotated in Scaled-YOLOv4 format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Fit (black edges))

The following augmentation was applied to create 20 versions of each source image:
* 50% probability of horizontal flip
* Random rotation of between -3 and +3 degrees
* Random exposure adjustment of between -25 and +25 percent


