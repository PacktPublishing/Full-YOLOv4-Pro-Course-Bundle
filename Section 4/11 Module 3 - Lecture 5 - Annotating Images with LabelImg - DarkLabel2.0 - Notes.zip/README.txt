DarkLabel Ver2.0
: Video/Image object labeling & annotation tool (Ver.2.0)

Main Features
- bounding box labeling of video & image objects
- support xml(pascal voc/imagenet), darknet yolo data format
- support user-defined data formats
- automatic box labeling by visual tracking
- labeling by linear interpolation
- user-defined hotkeys and zoom in / zoom out support
- windows only (64 bits system)

Usage Instruction
	Arrow/PgUp/PgDn/Home/End: navigate image frames
	
	Mouse: Left(create box), Right(cancel latest)
	Shift+Mouse: Left(modify box), Right(delete selected/all)
	Shift+DoubleClick: modify box properties (label, ID, difficulty)
	
	Ctrl+DoubleClick: select/deselect box trajectory
	*box trajectory: linked boxes over frames with the same ID and label
	
	Ctrl+'+'/'-': zoom in/out
	Ctrl+Arrow: scroll zoomed window
	Ctrl+MouseWheel: zoom in/out
	Ctrl+Mouse: scroll zoomed window
	
	Enter: apply tracking (newly created boxes only)
	Ctrl+'s': save gt
	
	User-defined format & program configuration -> edit 'darklabel.yml'	

website & download: http://darkpgmr.tistory.com/16
contact: darkpgmr.lee@gmail.com
