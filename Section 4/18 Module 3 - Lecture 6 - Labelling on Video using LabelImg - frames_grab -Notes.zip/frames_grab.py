import os
import cv2
import argparse

ap = argparse.ArgumentParser()
ap.add_argument("-i", "--inputfilepath", required=True, help="path to input filepath")
ap.add_argument("-n", "--numframe",  default = 15, required=False, help="number of frame for extraction after every n frame")
args = vars(ap.parse_args())

video_file = args["inputfilepath"]
cap = cv2.VideoCapture(str(video_file))
total_frames = cap.get(7)
print("Total Frames: ", total_frames)

frame_id = 1
while (cap.isOpened()):
    ret, frame = cap.read()
    if not ret:
        break

    if frame_id % int(args["numframe"]) == 0:
        output_path = "./output_frame/" + os.path.basename(args["inputfilepath"])[:-4] + f"frame{frame_id}.jpg"
        cv2.imwrite(output_path, frame)
    frame_id += 1